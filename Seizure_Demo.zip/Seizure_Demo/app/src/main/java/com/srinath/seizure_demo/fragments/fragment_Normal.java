package com.srinath.seizure_demo.fragments;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Movie;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.srinath.seizure_demo.Normal_dataset;
import com.srinath.seizure_demo.NormalListAdaptor;
import com.srinath.seizure_demo.R;
import com.srinath.seizure_demo.RecyclerTouchListener;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class fragment_Normal extends Fragment {
    private List<Normal_dataset> NormalList = new ArrayList<>();
    private RecyclerView recyclerView;
    private NormalListAdaptor mAdapter;

    View view;
    Button nor;

    public fragment_Normal() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_normal, container, false);

        nor = (Button) view.findViewById(R.id.nor);
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);

        mAdapter = new NormalListAdaptor(NormalList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getContext(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {

                // Setting Dialog Title
                alertDialog.setTitle("NORMAL ALERT");

                // Setting Dialog Message
                alertDialog.setMessage(" You Are Normal Don't Worry !");

                // Setting Icon to Dialog
                alertDialog.setIcon(R.drawable.tick);

                // Showing Alert Message
                alertDialog.show();
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));


        nor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prepareMovieData();
                Toast t = Toast.makeText(getContext(), "Normal List", Toast.LENGTH_SHORT);
                t.show();




            }
        });

        return view;
    }



    private void prepareMovieData() {

        Normal_dataset normal_dataset = new Normal_dataset("986.234.457.28.2", "Reading 1", "1986","0");
        NormalList.add(normal_dataset);

        normal_dataset = new Normal_dataset("000.234.457.28.5", "Reading 2", "2000","0");
        NormalList.add(normal_dataset);

        normal_dataset = new Normal_dataset("008.234.457.28.1", "Reading 3", "2008","0");
        NormalList.add(normal_dataset);

        normal_dataset = new Normal_dataset("009.234.457.28.4", "Reading 4", "2009","0");
        NormalList.add(normal_dataset);

        normal_dataset = new Normal_dataset("009.234.457.28.6", "Reading 5", "2009","1");
        NormalList.add(normal_dataset);

        normal_dataset = new Normal_dataset("014.234.457.28.0", "Reading 6", "2014","1");
        NormalList.add(normal_dataset);

        normal_dataset = new Normal_dataset("015.234.457.28.5 ", "Reading 7", "2015","0");
        NormalList.add(normal_dataset);

        normal_dataset = new Normal_dataset("015.234.457.28.7", "Reading 8", "2015","0");
        NormalList.add(normal_dataset);

        normal_dataset = new Normal_dataset("015.234.457.28.14", "Reading 9", "2015","0");
        NormalList.add(normal_dataset);

        normal_dataset = new Normal_dataset("015.234.457.28.22", "Reading 10", "2015","0");
        NormalList.add(normal_dataset);

        mAdapter.notifyDataSetChanged();


    }
}


