package com.srinath.seizure_demo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Login_Activity extends AppCompatActivity {
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loding Data ...");
        progressDialog.setCancelable(false);
        progressDialog.setTitle("Please Wait..");


    }

    public void login(View view) {

        progressDialog.show();

        new Handler().postDelayed(new Runnable() {

// Using handler with postDelayed called runnable run method

            @Override

            public void run() {
                progressDialog.dismiss();

                Intent i = new Intent(Login_Activity.this, dash_Board.class);
                startActivity(i);
                finish();

            }

        }, 4* 2000); // wait for 5 seconds


//        Intent i=new Intent(Login_Activity.this,dash_Board.class);
//        startActivity(i);
//        finish();
    }
}

