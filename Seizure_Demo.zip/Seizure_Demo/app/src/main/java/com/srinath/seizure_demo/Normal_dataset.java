package com.srinath.seizure_demo;


public class Normal_dataset {
        private String title, genre, year,value;



        public Normal_dataset(String title, String genre, String year,String value) {
            this.title = title;
            this.genre = genre;
            this.year = year;
            this.value=value;
        }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}

