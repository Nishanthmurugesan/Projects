package com.srinath.seizure_demo.fragments;


import android.app.AlertDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.srinath.seizure_demo.NormalListAdaptor;
import com.srinath.seizure_demo.Normal_dataset;
import com.srinath.seizure_demo.R;
import com.srinath.seizure_demo.RecyclerTouchListener;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class fragment_Eplisey extends Fragment {

    private List<Normal_dataset> NormalList = new ArrayList<>();
    private RecyclerView recyclerView;
    private NormalListAdaptor mAdapter;

    Button nor1;
    View view;
    public fragment_Eplisey() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        view = inflater.inflate(R.layout.fragment__eplisey, container, false);
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view1);

        mAdapter = new NormalListAdaptor(NormalList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getContext(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {

                // Setting Dialog Title
                alertDialog.setTitle(" EPLISEY ALERT  ");

                // Setting Dialog Message
                alertDialog.setMessage("  Eplisey Emergency !");

                // Setting Icon to Dialog
                alertDialog.setIcon(R.drawable.tick1);

                // Showing Alert Message
                alertDialog.show();
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));



        nor1 =(Button)view.findViewById(R.id.nor1);
nor1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        prepare1MovieData();
        Toast t = Toast.makeText(getContext(), "EPILEPSY LIST", Toast.LENGTH_SHORT);
        t.show();
        }
});
        return view;
    }

    private void prepare1MovieData() {
        Normal_dataset Eplisey_dataset = new Normal_dataset("986.234.457.28.23", "E Reading 1", "1986","1");
        NormalList.add(Eplisey_dataset);

        Eplisey_dataset = new Normal_dataset("000.234.457.28.55", "E Reading 2", "2000","1");
        NormalList.add(Eplisey_dataset);

        Eplisey_dataset = new Normal_dataset("008.234.457.28.12", "E Reading 3", "2008","1");
        NormalList.add(Eplisey_dataset);

        Eplisey_dataset = new Normal_dataset("009.234.457.28.48", "E Reading 4", "2009","1");
        NormalList.add(Eplisey_dataset);

        Eplisey_dataset = new Normal_dataset("009.234.457.28.65", "E Reading 5", "2009","1");
        NormalList.add(Eplisey_dataset);

        Eplisey_dataset = new Normal_dataset("014.234.457.28.80", "E Reading 6", "2014","1");
        NormalList.add(Eplisey_dataset);

        Eplisey_dataset = new Normal_dataset("015.234.457.28.45 ", "E Reading 7", "2015","1");
        NormalList.add(Eplisey_dataset);

        Eplisey_dataset = new Normal_dataset("015.234.457.28.77", "E Reading 8", "2015","1");
        NormalList.add(Eplisey_dataset);

        Eplisey_dataset =new Normal_dataset("015.234.457.28.54", "E Reading 9", "2015","1");
        NormalList.add(Eplisey_dataset);

        Eplisey_dataset =  new Normal_dataset("015.234.457.28.20", "E Reading 10", "2015","1");
        NormalList.add(Eplisey_dataset);

              mAdapter.notifyDataSetChanged();


    }


}



