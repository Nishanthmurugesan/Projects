package com.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import android.view.View as AndroidViewView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main);


    }

    override fun onBackPressed() {

    }

    fun count(view: AndroidViewView) {
        val ao: TextView = findViewById(R.id.textView)
        val na1 = ao.text.toString()

        val bo: TextView = findViewById(R.id.textView2)
        val na2 = bo.text.toString()


        val myToast = Toast.makeText(this, "Please Hold $na1", Toast.LENGTH_SHORT)
        myToast.show()


        var a1 = 0;
        var b1 = 0;
        var c1 = 0;
        var d1 = 0;
        var e1 = 0;
        var f1 = 0;
        var g1 = 0;
        var h1 = 0;
        var i1 = 0;
        var j1 = 0;
        var k1 = 0;
        var l1 = 0;
        var m1 = 0;
        var n1 = 0;
        var o1 = 0;
        var p1 = 0;
        var q1 = 0;
        var r1 = 0;
        var s1 = 0;
        var t1 = 0;
        var u1 = 0;
        var v1 = 0;
        var w1 = 0;
        var x1 = 0;
        var y1 = 0;
        var z1 = 0;


        var a2 = 0;
        var b2 = 0;
        var c2 = 0;
        var d2 = 0;
        var e2 = 0;
        var f2 = 0;
        var g2 = 0;
        var h2 = 0;
        var i2 = 0;
        var j2 = 0;
        var k2 = 0;
        var l2 = 0;
        var m2 = 0;
        var n2 = 0;
        var o2 = 0;
        var p2 = 0;
        var q2 = 0;
        var r2 = 0;
        var s2 = 0;
        var t2 = 0;
        var u2 = 0;
        var v2 = 0;
        var w2 = 0;
        var x2 = 0;
        var y2 = 0;
        var z2 = 0;

        var coot = 0


        for (ik in 0 until na1.length) {

            if ('A' == na1[ik] || 'a' == na1[ik]) {
                ++a1
            } else if ('B' == na1[ik] || 'b' == na1[ik]) {
                ++b1
            } else if ('C' == na1[ik] || 'c' == na1[ik]) {
                ++c1
            } else if ('D' == na1[ik] || 'd' == na1[ik]) {
                ++d1
            } else if ('E' == na1[ik] || 'e' == na1[ik]) {
                ++e1
            } else if ('F' == na1[ik] || 'f' == na1[ik]) {
                ++f1
            } else if ('G' == na1[ik] || 'g' == na1[ik]) {
                ++g1
            } else if ('H' == na1[ik] || 'h' == na1[ik]) {
                ++h1
            } else if ('I' == na1[ik] || 'i' == na1[ik]) {
                ++i1
            } else if ('J' == na1[ik] || 'j' == na1[ik]) {
                ++j1
            } else if ('K' == na1[ik] || 'k' == na1[ik]) {
                ++k1
            } else if ('L' == na1[ik] || 'l' == na1[ik]) {
                ++l1
            } else if ('M' == na1[ik] || 'm' == na1[ik]) {
                ++m1
            } else if ('N' == na1[ik] || 'n' == na1[ik]) {
                ++n1
            } else if ('O' == na1[ik] || 'o' == na1[ik]) {
                ++o1
            } else if ('P' == na1[ik] || 'p' == na1[ik]) {
                ++p1
            } else if ('Q' == na1[ik] || 'q' == na1[ik]) {
                ++q1
            } else if ('R' == na1[ik] || 'r' == na1[ik]) {
                ++r1
            } else if ('S' == na1[ik] || 's' == na1[ik]) {
                ++s1
            } else if ('T' == na1[ik] || 't' == na1[ik]) {
                ++t1
            } else if ('U' == na1[ik] || 'u' == na1[ik]) {
                ++u1
            } else if ('V' == na1[ik] || 'v' == na1[ik]) {
                ++v1
            } else if ('W' == na1[ik] || 'w' == na1[ik]) {
                ++w1
            } else if ('X' == na1[ik] || 'x' == na1[ik]) {
                ++x1
            } else if ('Y' == na1[ik] || 'y' == na1[ik]) {
                ++y1
            } else if ('Z' == na1[ik] || 'z' == na1[ik]) {
                ++z1
            } else {

            }
        }

        for (ik in 0 until na2.length) {

            if ('A' == na2[ik] || 'a' == na2[ik]) {
                ++a2
            } else if ('B' == na2[ik] || 'b' == na2[ik]) {
                ++b2
            } else if ('C' == na2[ik] || 'c' == na2[ik]) {
                ++c2
            } else if ('D' == na2[ik] || 'd' == na2[ik]) {
                ++d2
            } else if ('E' == na2[ik] || 'e' == na2[ik]) {
                ++e2
            } else if ('F' == na2[ik] || 'f' == na2[ik]) {
                ++f2
            } else if ('G' == na2[ik] || 'g' == na2[ik]) {
                ++g2
            } else if ('H' == na2[ik] || 'h' == na2[ik]) {
                ++h2
            } else if ('I' == na2[ik] || 'i' == na2[ik]) {
                ++i2
            } else if ('J' == na2[ik] || 'j' == na2[ik]) {
                ++j2
            } else if ('K' == na2[ik] || 'k' == na2[ik]) {
                ++k2
            } else if ('L' == na2[ik] || 'l' == na2[ik]) {
                ++l2
            } else if ('M' == na2[ik] || 'm' == na2[ik]) {
                ++m2
            } else if ('N' == na2[ik] || 'n' == na2[ik]) {
                ++n2
            } else if ('O' == na2[ik] || 'o' == na2[ik]) {
                ++o2
            } else if ('P' == na2[ik] || 'p' == na2[ik]) {
                ++p2
            } else if ('Q' == na2[ik] || 'q' == na2[ik]) {
                ++q2
            } else if ('R' == na2[ik] || 'r' == na2[ik]) {
                ++r2
            } else if ('S' == na2[ik] || 's' == na2[ik]) {
                ++s2
            } else if ('T' == na2[ik] || 't' == na2[ik]) {
                ++t2
            } else if ('U' == na2[ik] || 'u' == na2[ik]) {
                ++u2
            } else if ('V' == na2[ik] || 'v' == na2[ik]) {
                ++v2
            } else if ('W' == na2[ik] || 'w' == na2[ik]) {
                ++w2
            } else if ('X' == na2[ik] || 'x' == na2[ik]) {
                ++x2
            } else if ('Y' == na2[ik] || 'y' == na2[ik]) {
                ++y2
            } else if ('Z' == na2[ik] || 'z' == na2[ik]) {
                ++z2
            } else {

            }

        }


        coot = coot + abs(a1 - a2)
        coot = coot + abs(b1 - b2)
        coot = coot + abs(c1 - c2)
        coot = coot + abs(d1 - d2)
        coot = coot + abs(e1 - e2)
        coot = coot + abs(f1 - f2)
        coot = coot + abs(g1 - g2)
        coot = coot + abs(h1 - h2)
        coot = coot + abs(i1 - i2)
        coot = coot + abs(j1 - j2)
        coot = coot + abs(k1 - k2)
        coot = coot + abs(l1 - l2)
        coot = coot + abs(m1 - m2)
        coot = coot + abs(n1 - n2)
        coot = coot + abs(o1 - o2)
        coot = coot + abs(p1 - p2)
        coot = coot + abs(q1 - q2)
        coot = coot + abs(r1 - r2)
        coot = coot + abs(s1 - s2)
        coot = coot + abs(t1 - t2)
        coot = coot + abs(u1 - u2)
        coot = coot + abs(v1 - v2)
        coot = coot + abs(w1 - w2)
        coot = coot + abs(x1 - x2)
        coot = coot + abs(y1 - y2)
        coot = coot + abs(z1 - z2)

        if (na1.isEmpty() || na2.isEmpty()) {

            val tos = Toast.makeText(this, "fill all Fields", Toast.LENGTH_SHORT)
            tos.show()
        } else {
            if ((coot == 1) || (coot == 17) || (coot == 19)) {
                val intent = Intent(this, Sisbro::class.java)
                startActivity(intent)
            } else if ((coot == 6) || (coot == 11) || (coot == 15)) {
                val intent = Intent(this, Marriage::class.java)
                startActivity(intent)
            } else if ((coot == 2) || (coot == 3) || (coot == 4) || (coot == 7) || (coot == 9)) {
                val intent = Intent(this, Enemy::class.java)
                startActivity(intent)
            } else if ((coot == 5) || (coot == 8) || (coot == 12) || (coot == 13) || (coot == 20)) {
                val intent = Intent(this, Affection::class.java)
                startActivity(intent)
            } else if ((coot == 14) || (coot == 16) || (coot == 18)) {
                val intent = Intent(this, Friends::class.java)
                startActivity(intent)
            } else if ((coot == 10)) {
                val intent = Intent(this, Main2Activity::class.java)
                startActivity(intent)
            }


        }



    }

    fun tostme(view: android.view.View) {
        var ao: TextView = findViewById(R.id.textView)
        var na1 = ao.run { text.toString() }
        val myToast = Toast.makeText(this, "Hi $na1 :)", Toast.LENGTH_SHORT)
        myToast.show()
    }
}
